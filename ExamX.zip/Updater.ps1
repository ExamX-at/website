﻿[Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}

$url = "https://public.max-burger.at/storage/ExamX/ExamX.zip"
$user = "ExamX"
$password = "examx"

#Checking for recovery
Unblock-File 'C:\Program Files (x86)\ExamX\ExamX_Client\Assets\RecoveryScript.ps1'
Invoke-Expression "& 'C:\Program Files (x86)\ExamX\ExamX_Client\Assets\RecoveryScript.ps1'" -ErrorAction SilentlyContinue

#Stopping all ExamX related Apps
Get-Process |? {$_.ProcessName -match ".*ExamX.*"} | Stop-Process

# Output file path into current directory.
$file= ($pwd).path + "\ExamX.zip"
Write-Host "Exporting data to: $file"

$webclient = New-Object System.Net.WebClient
$basic = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($user + ":" + $password));
$webclient.Headers["Authorization"] = "Basic $basic"
$webclient.DownloadFile($url, $file)
Write-Host "File Downloaded"
Write-Host "Removing old versions"
Remove-Item -Recurse -Force "C:\Program Files (x86)\ExamX\"

Write-Host "Extracting .zip"
Expand-Archive -Path $file -DestinationPath "C:\Program Files (x86)\" -Force
Write-Host "Archive extracted to: C:\Program Files (x86)"
Write-Host "Removing $file"
rm $file
Write-Host "File Removed"
Write-Host "Finished with Update"

powershell -command "Remove-Item -Recurse -Force -ErrorAction SilentlyContinue C:\Users\public\ExamX"